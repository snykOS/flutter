foo@bar.baz
