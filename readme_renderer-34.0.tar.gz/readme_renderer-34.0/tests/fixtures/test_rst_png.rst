.. image:: https://example.com/badge.png
