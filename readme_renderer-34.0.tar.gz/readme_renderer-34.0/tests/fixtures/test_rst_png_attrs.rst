.. image:: https://example.com/badge.png
   :height: 100px
   :width: 25.0%
   :alt: alternate text
   :align: right
