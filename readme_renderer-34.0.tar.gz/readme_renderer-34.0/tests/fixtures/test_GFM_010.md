This ~text~~~~ is ~~~~curious~.
