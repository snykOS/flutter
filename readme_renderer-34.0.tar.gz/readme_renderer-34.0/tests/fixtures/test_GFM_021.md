hello@mail+xyz.example isn't valid, but hello+xyz@mail.example is.
