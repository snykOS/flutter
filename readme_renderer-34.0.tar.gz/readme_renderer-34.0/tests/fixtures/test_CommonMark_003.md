## Required packages

To run the PyPI software, you need Python 2.5+ and PostgreSQL

## Quick development setup
Make sure you are sitting
