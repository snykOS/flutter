<a href="http://mymalicioussite.com/">Click here</a>
