<h1>Required packages</h1>
<p>To run the PyPI software, you need Python 2.5+ and PostgreSQL</p>
<h1>Quick development setup</h1>
<p>Make sure you are sitting</p>