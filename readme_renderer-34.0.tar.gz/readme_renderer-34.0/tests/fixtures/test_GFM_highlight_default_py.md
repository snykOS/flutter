```python
async def this_is_python():
    pass

print(await this_is_python())
```
