Development Lead
----------------

- Ian Stapleton Cordasco <graffatcolmingov@gmail.com>

Contributors
------------

- Thomas Weißschuh
- Kostya Esmukov
- Derek Higgins
- Victor Stinner
- Viktor Haag
- Seth Michael Larson
